﻿// MIS 3013 001
// Jan 31, 2024
// Andrea Hernandez
// 113552217

// string.Format()
// Format is function, is a machine, coffe maker
// string. fucntion belongs to string
// Format() is a function call, press the start button

int age1;
double w1;
double m1;
double p1;
age1 = 21;
w1 = 128.6;// lbs
m1 = 20.6;
p1 = 0.15;

string mesStr;
mesStr = string.Format($"The age is {age1}The weight is w1");

Console.WriteLine(mesStr);



